$(document).ready(function(){
	
	// Lift card and show stats on Mouseover
	$('.product-card').hover(function(){
			$(this).addClass('animate');
						
		 }, function(){
			$(this).removeClass('animate');			

	});	
	
});