<!--<html>
<head>
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="navestilo.css">
</head>
<body>
-->
<nav>
    <div class="parent2">
      <a href="<?= base_url('item/index')?>" ><div class="test1">
          <i class="fa fa-home fa-2x center-icon"></i>
      </div></a>
      <a href="<?= base_url('item/pesquisa_item')?>"><div class="test2">
          <i class="fa fa-search fa-2x center-icon"></i>
      </div></a>
       <a href="<?= base_url('item/cadastrarItem')?>" ><div class="test3">
          <i class="fa fa-plus fa-2x center-icon"></i>
           </div></a>
      <a href="<?= base_url('usuario/index')?>"><div class="test4">
         <i class="fa fa-envelope-o fa-2x center-icon"></i>
          </div></a>
      <div class="mask2">
          <i class="fa fa-bars fa-3x center-icon"></i>
      </div>
    </div>
</nav>
<!--
<script src="jquery-2.2.0.min.js" type="text/javascript"></script>
<script src="navscript.js" type="text/javascript"></script>
</body>
</html>

-->